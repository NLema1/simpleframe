# simpleframe

**Readable Polars wrappers so AI-generated data code makes sense to humans.**

The vibe-coding era has a problem: AI writes code, you run it, and you have no idea what just happened. `simpleframe` fixes that. Tell AI to use `simpleframe` and the code it produces will read like English — and when you're ready, you can call `.show_polars()` to see the equivalent real Polars code and graduate.

```bash
pip install simpleframe
```

## The pitch

You're not anti-AI. You're pro-literacy. Don't stop using AI. Stop being blind to what it's doing.

```python
# What AI usually writes:
df = pl.read_csv("sales.csv").filter(pl.col("amount") > 100).group_by("region").agg(pl.col("amount").sum())

# What AI writes when you ask it to use simpleframe:
df = I_want_a.csv("sales.csv")
df = I_want_to.filter(df, where="amount > 100")
df = I_want_to.group_and_summarize(df, group_by="region", summarize="amount", using="sum")
```

When you want to learn the real syntax, just ask:

```python
df.show_polars()
```

```text
import polars as pl

df = pl.read_csv("sales.csv")
df = df.sql("SELECT * FROM self WHERE amount > 100")
df = df.group_by("region").agg(pl.col("amount").sum().alias("amount"))
```

## Quick start

```python
from simpleframe import I_want_a, I_want_to

# Create
df = I_want_a.dataframe({
    "name": ["Alice", "Bob", "Charlie"],
    "age": [30, 25, 35],
    "salary": [50000, 60000, 70000],
})

# Transform
df = I_want_to.filter(df, where="age > 26")
df = I_want_to.add_column(df, name="bonus", formula="salary * 0.1")
df = I_want_to.sort(df, by="bonus", descending=True)

# See your data
df.see()

# See the real Polars code behind it
df.show_polars()
```

## What's available in v1

**Creation (`I_want_a`):**
`dataframe`, `csv`, `excel`, `json`, `parquet`, `sample`

**Transformations (`I_want_to`):**
`filter`, `sort`, `select`, `add_column`, `rename`, `drop`, `group_and_summarize`, `join`, `fill_missing`, `drop_missing`, `uppercase`, `lowercase`, `keep_where_contains`, `split_column`

**On any SimpleFrame:**
- `.see()` — pretty-print the data
- `.show_polars()` — show the real Polars code
- `.to_polars()` — get the underlying Polars DataFrame

## Telling AI to use it

Drop this in your AI prompt:

> Use the `simpleframe` Python package. Import `I_want_a` for creating dataframes and `I_want_to` for transformations. Methods read like English: `I_want_to.filter(df, where="age > 30")`.

## License

MIT
